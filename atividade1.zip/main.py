import machine
import time 

led1 = machine.Pin(14, machine.Pin.OUT)
led2 = machine.Pin(13, machine.Pin.OUT)
led3 = machine.Pin(12, machine.Pin.OUT)
botão1 = machine.Pin(33, machine.Pin.IN, machine.Pin.PULL_UP)
botão2 = machine.Pin(34, machine.Pin.IN, machine.Pin.PULL_UP)
botão3 = machine.Pin(35, machine.Pin.IN, machine.Pin.PULL_UP)

while (True) :
    estado = botão1.value()
    if (estado == 0):
        print ("botão1 pressionado!!! HAHAHAHAHAH")
        led1.on()
    else:
        led1.off()
        time.sleep(0.10)

    estado2 = botão2.value()
    if (estado2 == 0):
        print ("botão2 pressionado!!! HAHAHAHAHAH")
        led2.on()
    else:
        led2.off()
        time.sleep(0.10)

    estado3 = botão3.value()
    if (estado3 == 0):
        print ("botão3 pressionado!!! HAHAHAHAHAH")
        led3.on()
    else:
        led3.off()
        time.sleep(0.10)